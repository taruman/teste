<!DOCTYPE html>
<html lang="pt_BR">
<head>
	<!-- META -->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="tags" content="moda, roupas, atacado, vendas, loja, varejo">
	<meta name="author" content="Sour Comunicação">

	<!-- TITLE & FAVICON -->
	<title>Fashion Finder</title>
	<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" href="/img/favicon-apple-touch.png">
	<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon-apple-touch-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon-apple-touch-114x114.png">

	<!-- LINK -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="/css/imports.css">
	<link rel="stylesheet" href="/css/normalize.css">
	<link rel="stylesheet" href="/css/fashionhunt-custom.css">

	<!-- SCRIPT -->
	<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
	<script src="https://ajax.microsoft.com/ajax/jquery.templates/beta1/jquery.tmpl.min.js"></script>

</head>
<body>
	<!-- NAVBAR -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="{{action('PecasController@index')}}">Logo</a>
				</div>
				
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="{{action('PecasController@index')}}">Home</a></li>
						@if(!Auth::check())
						<li><a href="#" data-toggle="modal" data-target="#entrar" class="entrar">Entrar</a></li>
						<li><a href="#" data-toggle="modal" data-target="#registrar" class="registrar">Registrar-se</a></li>
						@else
							@if(Auth::user()->type == 2)
							<li><a href="{{url('lojista/create/pecas')}}">Nova Peça</a></li>
							<li><a href="{{action('PecasController@pecasLojista')}}">Minhas Peças</a></li>
							<li><a href="{{action('PecasController@dashboardLojista')}}">Dashboard</a></li>
							<li><a href="{{action('UsersController@contaLojista')}}">Conta</a></li>
							@endif
							@if(Auth::user()->type == 1)
							<li><a href="{{action('CategoriasController@create')}}">+Categorias</a></li>
							<li><a href="{{action('PecasController@solicitacoes')}}">Solicitações Pendentes</a></li>
							<li><a href="{{action('PecasController@dashboardMaster')}}">Relatórios</a></li>
							@endif
							@if(Auth::user()->type == 3)
							<li><a href="{{action('UsersController@contaCliente')}}">Conta</a></li>
							@endif
							<li><a href="{{action('UsersController@logout')}}">Sair</a></li>
						@endif
					</ul>
				</div>
			</div>
		</div>
	</nav>

	<!-- LOGIN & REGISTER -->
	<div class="modal fade" id="entrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" style="z-index: 9999; position: absolute;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-sm-12" style="margin-top: -40px">
							<h4 class="text-center">Entrar no FashionHunt</h4>
						</div>

						<div class="col-sm-12">
							<!--<span class="fa-block-social fa fa-facebook-official"></span>-->
							<input type="button" class="form-control" name="facebook-login" value="Entrar com Facebook">
							<p class="text-center" style="margin-top: 13px"><span style="color: #E1E1E1;">──────</span> <span class="pacifico" style="color: #1C1C1C;">Ou se preferir</span> <span style="color: #E1E1E1;">──────</span></p>
						</div>

						<form method="POST" name="logar" id="logar" action="{{ url('usuarios/login') }}">
							{!! csrf_field() !!}
							<div class="col-sm-12">
								<span class="fa-block-sec fa fa-user"></span><input type="text" name="email" id="login" class="form-control" placeholder="Login">
							</div>
							<div class="col-sm-12">
								<span class="fa-block fa fa-lock"></span><input type="password" name="password" id="senha" class="form-control" placeholder="Senha">
							</div>
							<div class="col-sm-12">
								<input type="submit" name="entrar" id="entrar" data-loading-text="Entrando..." autocomplete="off" class="btn btn-custom-login btn-block" value="Entrar">
							</div>
						</form>

						<div class="col-sm-12">
							<a href="#" class="forgot">esqueci minha senha</a>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-12">
								<p class="text-center" style=""><span class="pacifico" style="color: #1C1C1C;">Ainda não tem uma conta?</span></p>
							</div>	
							<input type="button" class="btn btn-custom-register-o btn-block" value="Registre-se" data-toggle="modal" data-target="#registrar">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="registrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" style="z-index: 9999; position: absolute;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-header" style="padding: 0; margin-top: -30px;">
					<img src="http://placehold.it/400x250&text=Logo" class="img-responsive">
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-sm-12">
							<p class="text-center"><span class="pacifico" style="color: #1C1C1C; font-size: 1.5em;">Selecione uma opção:</span> <p style="text-align: center; margin-top: -8px; font-size: 1.1em; color: #C1C1C1;"><small>Eu sou...</small></p></p>

							<a href="{{url('usuarios/register/lojista')}}" type="button" name="entrar" id="entrar" class="btn btn-custom-login btn-block">Lojista</a>

							<a href="{{url('usuarios/register/cliente')}}" type="button" name="entrar" id="entrar" class="btn btn-custom-distribuidor btn-block">Cliente</a>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-12">
								<p class="text-center" style=""><span class="pacifico" style="color: #1C1C1C;">Já possuo uma conta</span></p>
							</div>	
							<input type="button" name="entrar" class="btn btn-custom-register btn-block" value="Entrar" data-toggle="modal" data-target="#entrar" class="entrar">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- PARALLAX SHOWCASE -->
	<div class="parallax-container">
		<div class="parallax">
			<img src="http://www.knittingindustry.com/uploads/2062/Shima-Fashion_SHow-50th-2.gif">
		</div>
	</div>

	<!-- BUTTONS & SEARCH -->
	<div class="filters-box">
		<div class="container">
			<button type="button" class="navbar-toggle secondary collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-2" aria-expanded="false">
				<span class="sr-only">Toggle navigation</span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
				<span class="icon-bar"></span>
			</button>
			<div class="row">
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-2">
					<div class="row">
						<div class="col-xs-12 col-sm-8">
							<a href="{{action('PecasController@populares')}}" class="btn btn-custom deactive">Popular</a>
							<a href="{{action('PecasController@recente')}}" class="btn btn-custom deactive">Recente</a>
							<a href="{{action('PecasController@lojistas')}}" class="btn btn-custom deactive">Lojistas</a>
							<!--<a href="" class="btn btn-custom deactive">Preço</a>-->
							@if(Auth::check() && Auth::user()->type == 3)
							<a href="{{action('PecasController@favoritos')}}" class="btn btn-custom deactive">Favoritos</a>
							<a href="{{action('PecasController@curtidas')}}" class="btn btn-custom deactive">Curtidas</a>
							@endif
							{!! Form::open(['route' => 'pecas.busca.categoria', 'method' => 'GET', 'name' => 'cat']) !!}
							<select name="id" id="busca_categoria" class="btn btn-custom deactive">
								<option value="" disabled selected>Categoria</option>
								@foreach($categorias as $categoria)
								<option value="{{$categoria->id}}">{{$categoria->nome_categoria}}</option>
								@endforeach
							</select>
							{!! Form::close() !!}
							{!! Form::open(['route' => 'pecas.busca.loja', 'method' => 'GET', 'name' => 'loj']) !!}
							<select name="id" id="busca_loja" class="btn btn-custom deactive">
								<option value="" disabled selected>Lojas</option>
								@foreach($lojas as $loja)
								<option value="{{$loja->id}}">{{$loja->name}}</option>
								@endforeach
							</select>
							{!! Form::close() !!}
						</div>
						{!! Form::open(['route' => 'pecas.busca', 'method' => 'GET', 'name' => 'busca']) !!}
						<div class="col-sm-4">
							<div class="input-group">
								<input name="palavras" type="text" class="col-xs-12 pull-right btn btn-custom-search deactive" placeholder="Buscar...">
								<span class="input-group-btn">
        							<button class="btn btn-custom-search" type="submit"><span class="fa fa-search"></span></button>
								</span>
							</div>
						</div>
						{!! Form::close() !!}
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- CONTENT -->
	<div class="container" style="margin-top: 20px;">
		<div class="row">

		@if(Session::has('sucesso'))
		    <div class="alert alert-success">
		        <h4>{{ Session::get('sucesso') }}</h4>
		    </div>
		@endif

		@if(Session::has('fracasso'))
		    <div class="alert alert-danger">
		        <h4>{{ Session::get('fracasso') }}</h4>
		    </div>
		@endif

		@yield('content')


		</div>
	</div> 

	<br>
	<br>

	<!-- FOOTER -->
	<footer class="footer">
		<div class="container">
			<p class="text-muted">&copy; Fashion Hunt, 2015. | Todos os direitos reservados.</p>
		</div>
	</footer>

	<!-- SCRIPT -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="//cdn.jsdelivr.net/isotope/1.5.25/jquery.isotope.min.js"></script>
	<script src="/js/progressive_loading.js"></script>
	<script src="/js/materialize.min.js"></script>
	<script src="/js/fwfunctions.js"></script>
	<script src="/js/nav-scroll.js"></script>
	<!--<script>
		$(document).bind("contextmenu",function(e) {
     		e.preventDefault();
		});
	</script>-->
	<script type="text/javascript">
		$(document).ready( function() {

			//lógica de curtir
			$(".curtir").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('pecas/curtir/') ?>";
				url = url + '/' + id;
				$.getJSON(url)
				.done(function(data){
					if(data.tipo == 'descurtir')
					{
						var cor = $(data.id).parent().find(".cor");
						cor.css("color", "black");
					}
					else if(data.tipo == 'curtir')
					{
						var total = $(data.id).parent().find(".total");
						var cor = $(data.id).parent().find(".cor");
						cor.css("color", "red");
						total.text(data.total);
					}

				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de seguir
			$(".seguir").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('cliente/seguir') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("seguindo lojista");
				}, "json")
				.done(function(data){
					if(data.tipo == 'desseguir')
					{
						$(data.classe).text('(SEGUIR?)');
					}
					else if(data.tipo == 'seguir')
					{
						$(data.classe).text('(SEGUINDO)');
					}

				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de excluir peca
			$(".excluir").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('lojista/delete/pecas') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("excluindo peca");
				}, "json")
				.done(function(data){
					if(data.tipo == 'fracasso')
					{
						alert("essa peça não é sua");
					}

					if (data.tipo == 'sucesso') 
					{
						$(data.id).fadeOut(1000, function(){
							$(this).remove();
						});
					}
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//apenas clientes podem curtir
			$(".n-cliente").on("click", function(e){
				e.preventDefault();
				alert("lojistas não podem curtir as peças");
			});			

			//busca por categoria
			$("#busca_categoria").on("change", function(){
				$("form[name='cat']").submit();
			});

			//busca por loja
			$("#busca_loja").on("change", function(){
				$("form[name='loj']").submit();
			});

			/* activate jquery isotope */
			$('#posts').imagesLoaded( function(){
				$('#posts').isotope({
					itemSelector : '.post'
				});
			});
			  
		});
	</script>
</body>
</html>