@extends('template_two')

@section('content')
	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Dashboard</span> <span style="color: #E1E1E1;">───</span></p><br />
	
	<div class="row">
		<div class="col-sm-6" id="clients">
			<h3>Quem me curte</h3>
	        <input class="search" placeholder="Busca" />
	        <button class="sort" data-sort="name">
	            inverter ordem
	        </button>
	        <ul class='list'>
			@foreach($users as $user)
				<li><p class="name">{{$user["nome"]}}</p></li>
			@endforeach
			</ul>
		</div>
		<div class="col-sm-6">
			<h3>Peças curtidas nos últimos 3 meses</h3>
			<p>{{$pecas_curtidas}}</p>
		</div>
	</div>

@endsection