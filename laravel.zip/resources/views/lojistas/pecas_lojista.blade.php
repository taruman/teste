@extends('template')

@section('content')
	@if(Auth::check() && Auth::user()->type == 2)
		<div id="posts" class="row">
			@foreach($pecas as $peca)

			<!-- Modal -->
			<div class="modal fade bs-example-modal-lg" id="myModal{{$peca->id}}" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
			    <div class="modal-dialog modal-lg" role="document">
				    <div class="modal-content">
				        <div class="modal-header">
					        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
					        <h4 class="modal-title" id="myModalLabel">{{$peca->nome_peca}}</h4>
				        </div>
				        <div class="modal-body">	
							<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
				        </div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-sm-6">
									<small>({{$peca->usuario->name}})</small>
								</div>
								<div class="col-sm-6">			
									<p class="text-right fav-counter">
										<span style="color:red;" class="fa fa-heart"></span> 
										<strong> {{ $peca->curtidas_peca }}</strong>
									</p>										
								</div>
							</div>
							<hr>
							<h4> 
								<p><small>{{$peca->descricao_peca}}</small></p>
								@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
									<small>#{{$categoria->nome_categoria}} </small>
								@endforeach
							</h4>
						</div>
				    </div>
			    </div>
			</div>

			<div id="peca{{$peca->id}}" class="col-sm-3 post">
				<div class="panel panel-default">
					<div class="panel-body">
						<a href="#" class="img-responsive n-cliente"><span class="fa fa-heart fa-3x"></span></a>
						<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
					</div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-sm-6">
								<a href="#" class="excluir"><small>EXCLUIR</small></a>
								<input type='hidden' value='{{$peca->id}}'>
							</div>
							<div class="col-sm-6">
								<a href="#" class="n-cliente">
									<p class="text-right fav-counter">
										<span class="fa fa-heart"></span> 
										<strong> {{ $peca->curtidas_peca }}</strong>
									</p>
								</a>								
							</div>
						</div>

						<hr>

						<h4><a href="#" data-toggle="modal" data-target="#myModal{{$peca->id}}">{{$peca->nome_peca}}</a> 
							<p><small>{{str_limit($peca->descricao_peca, 30)}}</small></p>
							@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
								<small>#{{$categoria->nome_categoria}} </small>
							@endforeach
						</h4>
					</div>
				</div>
			</div>
			@endforeach
		</div>
	@endif
	
	{!! $pecas->render() !!}

@endsection