@extends('template_two')

@section('content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

{!! Form::open(['route' => 'lojista.edit']) !!}

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Dados do Lojista</span> <span style="color: #E1E1E1;">───</span></p><br />

	<div class="col-sm-6">
		<div class="">
			<label for="">Nome da Loja</label>
			<input value="{{ $lojista->name }}" type="text" name="name" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CNPJ</label>
			<input value="{{ $lojista->lojista->doc_lojista }}" type="text" name="doc" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Endereço</label>
			<input value="{{ $lojista->lojista->endereco_lojista }}" type="text" name="endereco" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CEP</label>
			<input value="{{ $lojista->lojista->cep_lojista }}" type="text" name="cep" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Telefone</label>
			<input value="{{ $lojista->lojista->telefone_lojista }}" type="text" name="telefone" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">E-mail</label>
			<input value="{{ $lojista->email }}" type="text" name="email" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Instagram</label>
			<input value="{{ $lojista->lojista->instagram_lojista }}" type="text" name="instagram" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Facebook</label>
			<input value="{{ $lojista->lojista->facebook_lojista }}" type="text" name="facebook" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Site</label>
			<input value="{{ $lojista->lojista->site_lojista }}" type="text" name="site" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Senha</label>
			<input type="password" name="password" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>
	
	<!-- BOTÃO ENVIO -->
	<div class="col-sm-12">
		<button type="submit" class="btn btn-danger btn-block">Editar</button>
	</div>


{!! Form::close() !!}


@endsection

