@extends('template')

@section('content')

	<div id="posts" class="row">
	@foreach($pecas as $peca)

		<!-- Modal -->
		<div class="modal fade bs-example-modal-lg" id="myModal{{$peca->id}}" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
		    <div class="modal-dialog modal-lg" role="document">
			    <div class="modal-content">
			        <div class="modal-header">
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				        <h4 class="modal-title" id="myModalLabel">{{$peca->nome_peca}}</h4>
			        </div>
			        <div class="modal-body">	
						<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
			        </div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-sm-6">
								<small>({{$peca->usuario->name}})</small>
							</div>
							<div class="col-sm-6">			
								<p class="text-right fav-counter">
									<span style="color:red;" class="fa fa-heart"></span> 
									<strong> {{ $peca->curtidas_peca }}</strong>
								</p>										
							</div>
						</div>
						<hr>
						<h4> 
							<p><small>{{$peca->descricao_peca}}</small></p>
							@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
								<small>#{{$categoria->nome_categoria}} </small>
							@endforeach
						</h4>
					</div>
			    </div>
		    </div>
		</div>

		<div class="col-sm-3 post">
			<!-- se estiver logado -->
			@if(Auth::check())

				<!-- se for cliente -->
				@if(Auth::user()->type == 3)
					<?php $curtiu = false; ?>
					<?php $seguiu = false; ?>
					@foreach($peca->usuarios as $usuario)
						@if($usuario->id == Auth::user()->id)
							<?php $curtiu = true; ?>
						@endif
					@endforeach

					@if(count(Auth::user()->cliente->seguidos))
						@foreach(Auth::user()->cliente->seguidos as $seguido)
							@if($seguido->user->id == $peca->usuario->id)
								<?php $seguiu = true; ?>
							@endif
						@endforeach
					@endif
					
					<!-- se já curtiu a peça -->
					@if($curtiu)
					<div id="{{$peca->id}}" class="panel panel-default">
						<div class="panel-body">
							<a href="#" class="img-responsive curtir"><span class="fa fa-heart fa-3x"></span></a>
							<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
							<input class="valor" type='hidden' value='{{$peca->id}}'>
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-sm-6">
									@if(Auth::user()->type == 3)
										@if($seguiu)
										<a href="#" class="img-responsive seguir"><small>{{$peca->usuario->name}} </small><small class="seguidos{{$peca->usuario->id}}">(seguindo)</small></a>
										<input type='hidden' value='{{$peca->usuario->id}}'>
										@else
										<a href="#" class="img-responsive seguir"><small>{{$peca->usuario->name}} </small><small class="seguidos{{$peca->usuario->id}}">(seguir?)</small></a>
										<input type='hidden' value='{{$peca->usuario->id}}'>
										@endif
									@else
									<small>({{$peca->usuario->name}})</small>
									@endif
								</div>
								<div class="col-sm-6">
									<a class="curtir" href="#">
										<p class="text-right fav-counter">
											<span style="color:red" class="cor fa fa-heart"></span> 
											<strong class="total"> {{ $peca->curtidas_peca }}</strong>
										</p>
									</a>
									<input class="valor" type='hidden' value='{{$peca->id}}'>
								</div>
							</div>

							<hr>

							<h4><a href="#" data-toggle="modal" data-target="#myModal{{$peca->id}}">{{$peca->nome_peca}}</a>
								<p><small>{{str_limit($peca->descricao_peca, 30)}}</small></p>
								@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
									<small>#{{$categoria->nome_categoria}} </small>
								@endforeach
							</h4>

						</div>
					</div>

					<!-- se não curtiu a peça -->
					@else
					<div id="{{$peca->id}}" class="panel panel-default">
						<div class="panel-body">
							<a href="#" class="img-responsive curtir"><span class="fa fa-heart fa-3x"></span></a>
							<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
							<input class="valor" type='hidden' value='{{$peca->id}}'>
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-sm-6">
									@if(Auth::user()->type == 3)
										@if($seguiu)
										<a href="#" class="img-responsive seguir"><small>{{$peca->usuario->name}} </small><small class="seguidos{{$peca->usuario->id}}">(seguindo)</small></a>
										<input type='hidden' value='{{$peca->usuario->id}}'>
										@else
										<a href="#" class="img-responsive seguir"><small>{{$peca->usuario->name}} </small><small class="seguidos{{$peca->usuario->id}}">(seguir?)</small></a>
										<input type='hidden' value='{{$peca->usuario->id}}'>
										@endif
									@else
									<small>({{$peca->usuario->name}})</small>
									@endif
								</div>
								<div class="col-sm-6">
									<a class="curtir" href="#">
										<p class="text-right fav-counter">
											<span class="cor fa fa-heart"></span> 
											<strong class="total"> {{ $peca->curtidas_peca }}</strong>
										</p>
									</a>
									<input class="valor" type='hidden' value='{{$peca->id}}'>
								</div>
							</div>

							<hr>

							<h4><a href="#" data-toggle="modal" data-target="#myModal{{$peca->id}}">{{$peca->nome_peca}}</a> 
								<p><small>{{str_limit($peca->descricao_peca, 30)}}</small></p>
								@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
									<small>#{{$categoria->nome_categoria}} </small>
								@endforeach
							</h4>
						</div>
					</div>
					@endif

				<!-- se for lojista ou master -->
				@else
				<div class="panel panel-default">
					<div class="panel-body">
						<a href="#" class="img-responsive n-cliente"><span class="fa fa-heart fa-3x"></span></a>
						<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
					</div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-sm-6">
								<small>({{$peca->usuario->name}})</small>
							</div>
							<div class="col-sm-6">
								<a href="#" class="n-cliente">
									<p class="text-right fav-counter">
										<span class="fa fa-heart"></span> 
										<strong> {{ $peca->curtidas_peca }}</strong>
									</p>
								</a>								
							</div>
						</div>

						<hr>

						<h4><a href="#" data-toggle="modal" data-target="#myModal{{$peca->id}}">{{$peca->nome_peca}}</a> 
							<p><small>{{str_limit($peca->descricao_peca, 30)}}</small></p>
							@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
								<small>#{{$categoria->nome_categoria}} </small>
							@endforeach
						</h4>
					</div>
				</div>
				@endif

			<!-- se não estiver logado -->
			@else
			<div class="panel panel-default">
				<div class="panel-body">
					<a data-toggle="modal" data-target="#entrar" href="#" class="img-responsive entrar"><span class="fa fa-heart fa-3x"></span></a>
					<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
				</div>
				<div class="panel-footer">
					<div class="row">
						<div class="col-sm-6">
							<small>({{$peca->usuario->name}})</small>
						</div>
						<div class="col-sm-6">
							<a href="#" data-toggle="modal" data-target="#entrar" class="entrar">
								<p class="text-right fav-counter">
									<span class="fa fa-heart"></span> 
									<strong> {{ $peca->curtidas_peca }}</strong>
								</p>
							</a>								
						</div>
					</div>

					<hr>

					<h4><a href="#" data-toggle="modal" data-target="#myModal{{$peca->id}}">{{$peca->nome_peca}}</a> 
						<p><small>{{str_limit($peca->descricao_peca, 30)}}</small></p>
						@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
							<small>#{{$categoria->nome_categoria}} </small>
						@endforeach
					</h4>
				</div>
			</div>
			@endif
		</div>
	@endforeach
	</div>
	
	{!! $pecas->render() !!}

@endsection