@extends('template_two')

@section('content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

{!! Form::open(['route' => 'lojista.store.pecas', 'files' => true]) !!}

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Cadastro de Peças</span> <span style="color: #E1E1E1;">───</span></p><br />

	<div class="col-sm-12">
		<div class="">
			<label for="">Nome</label>
			<input value="{{ old('nome_peca') }}" type="text" name="nome_peca" id="" class="data form-control" value="" style="margin-bottom: 20px">
		</div>
	</div>	

	<div class="col-sm-12">
		<div class="">
			<label for="">Descrição</label>
			<textarea name="descricao_peca" id="" class="data form-control" value="" style="margin-bottom: 20px">{{ old('descricao_peca') }}</textarea>
		</div>
	</div>

	<div class="col-sm-12">
		<div class="">
			<label for="">Código</label>
			<input value="{{ old('codigo_peca') }}" type="text" name="codigo_peca" id="" class="data form-control" value="" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-12">
		<label for="">Categorias</label>
		<div class="select-multiple">
			@foreach($categorias as $categoria)
				<input name="categorias[]" data-placeholder="Categorias" multiple="multiple" type="checkbox" value="{{$categoria['id']}}">{{$categoria['nome_categoria']}}
			@endforeach
		</div><br>
	</div>

	<div class="col-sm-12">
		<a id="outra_categoria" href="#">Outra categoria?</a><br><br>
		<div id='nova_categoria' style="display:none" class="">
			<input type="text" name="nova_categoria" id="" class="data form-control" value="" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-12">
		<div class="">
			<label for="">Foto</label>
			<input type="file" name="foto" id="" class="data" value="" style="margin-bottom: 20px">
		</div>
	</div>
	
	<!-- BOTÃO ENVIO -->
	<div class="col-sm-12">
		<button type="submit" class="btn btn-danger btn-block">Cadastrar</button>
	</div>


{!! Form::close() !!}


@endsection

