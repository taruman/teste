@extends('template')

@section('content')


{!! Form::open(['route' => 'usuarios.confirma']) !!}

<input type="text" name='email'>
<input type='password' name='password'>
<input type='submit' class='btn btn-default'>

{!! Form::close() !!}


@endsection