@extends('template_two')

@section('content')

<ul>
	@foreach($usuarios as $usuario)
		<li>{{$usuario->email}}</li>
		<ul>
			@foreach($usuario->pecas->where('nova_peca', 0)->get() as $peca)
				<li>{{$peca->nome_peca}}</li>
				<li>{{$peca->foto->caminho_foto}}</li>
				<ul>
					@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
						<li>{{$categoria->nome_categoria}}</li>
					@endforeach
				</ul>
			@endforeach
		</ul>
	@endforeach
</ul>

@endsection


