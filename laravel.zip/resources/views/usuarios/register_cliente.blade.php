@extends('template_two')

@section('content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

{!! Form::open(['route' => 'usuarios.create.cliente']) !!}

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Cadastro de Clientes</span> <span style="color: #E1E1E1;">───</span></p><br />

	<div class="col-sm-6">
		<div class="">
			<label for="">Nome Completo</label>
			<input value="{{ old('name') }}" type="text" name="name" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CNPJ ou CPF</label>
			<input value="{{ old('doc') }}" type="text" name="doc" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Endereço</label>
			<input value="{{ old('endereco') }}" type="text" name="endereco" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CEP</label>
			<input value="{{ old('cep') }}" type="text" name="cep" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Telefone</label>
			<input value="{{ old('telefone') }}" type="text" name="telefone" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">E-mail</label>
			<input value="{{ old('email') }}" type="text" name="email" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Instagram</label>
			<input value="{{ old('instagram') }}" type="text" name="instagram" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Facebook</label>
			<input value="{{ old('facebook') }}" type="text" name="facebook" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-12">
		<div class="">
			<label for="">Senha</label>
			<input type="password" name="password" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>
	
	<!-- BOTÃO ENVIO -->
	<div class="col-sm-12">
		<button type="submit" class="btn btn-danger btn-block">Cadastrar</button>
	</div>


{!! Form::close() !!}


@endsection

