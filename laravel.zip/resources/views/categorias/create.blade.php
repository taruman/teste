@extends('template_two')

@section('content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

{!! Form::open(['route' => 'master.store.categoria']) !!}

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Cadastro de Categorias</span> <span style="color: #E1E1E1;">───</span></p><br />

	<div class="col-sm-12">
		<div class="">
			<label for="">Nome da Categoria</label>
			<input value="{{ old('nome_categoria') }}" type="text" name="nome_categoria" id="" class="data form-control" value="" style="margin-bottom: 20px">
		</div>
	</div>
	
	<!-- BOTÃO ENVIO -->
	<div class="col-sm-12">
		<button type="submit" class="btn btn-danger btn-block">Cadastrar</button>
	</div>


{!! Form::close() !!}


@endsection

