@extends('template_two')

@section('content')

@if (count($errors) > 0)
  <div class="alert alert-danger">
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
    </ul>
  </div>
@endif

{!! Form::open(['route' => 'cliente.edit']) !!}

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Dados do Cliente</span> <span style="color: #E1E1E1;">───</span></p><br />

	<div class="col-sm-6">
		<div class="">
			<label for="">Nome Completo</label>
			<input value="{{ $cliente->name }}" type="text" name="name" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CNPJ ou CPF</label>
			<input value="{{ $cliente->cliente->doc_cliente }}" type="text" name="doc" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Endereço</label>
			<input value="{{ $cliente->cliente->endereco_cliente }}" type="text" name="endereco" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">CEP</label>
			<input value="{{ $cliente->cliente->cep_cliente }}" type="text" name="cep" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Telefone</label>
			<input value="{{ $cliente->cliente->telefone_cliente }}" type="text" name="telefone" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">E-mail</label>
			<input value="{{ $cliente->email }}" type="text" name="email" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Instagram</label>
			<input value="{{ $cliente->cliente->instagram_cliente }}" type="text" name="instagram" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-6">
		<div class="">
			<label for="">Facebook</label>
			<input value="{{ $cliente->cliente->facebook_cliente }}" type="text" name="facebook" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>

	<div class="col-sm-12">
		<div class="">
			<label for="">Senha</label>
			<input type="password" name="password" class="data form-control" style="margin-bottom: 20px">
		</div>
	</div>
	
	<!-- BOTÃO ENVIO -->
	<div class="col-sm-12">
		<button type="submit" class="btn btn-danger btn-block">Editar</button>
	</div>


{!! Form::close() !!}


@endsection

