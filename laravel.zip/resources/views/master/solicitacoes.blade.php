@extends('template_two')

@section('content')

	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Solicitações Pendentes</span> <span style="color: #E1E1E1;">───</span></p><br />
	
	<div class="row">
		<div class="col-sm-4">
			<h3>Novas Lojas</h3>
			@foreach($lojas as $loja)
				<div id="loja{{$loja->id}}" class="panel panel-default">
					<div class="panel-heading">
						<h3 class="panel-title">{{$loja->name}}</h3>
					</div>
					<div class="panel-body"><br>
						<div class="container">
							<p>CNPJ: {{$loja->lojista->cnpj_lojista}}</p>
							<p>Endereço: {{$loja->lojista->endereco_lojista}}</p>
							<p>CEP: {{$loja->lojista->cep_lojista}}</p>
							<p>Telefone: {{$loja->lojista->telefone_lojista}}</p>
							<p>E-mail: {{$loja->email}}</p>
							<p>Instagram: {{$loja->lojista->instagram_lojista}}</p>
							<p>Facebook: {{$loja->lojista->facebook_lojista}}</p>
							<p>Site: {{$loja->lojista->site_lojista}}</p>
						</div>
					</div>
					<div class="panel-footer">
						<div class="row">
						<div class="col-sm-6">
							<a href="#" class="aprovar-loja"><p class="text-left like-counter"><span class="fa fa-thumbs-up"></span> <strong>Sim</strong></p></a>
							<input type='hidden' value='{{$loja->id}}'>
						</div>
						<div class="col-sm-6">
							<a href="#" class="desaprovar-loja"><p class="text-right like-counter"><span class="fa fa-thumbs-down"></span> <strong>Não</strong></p></a>
							<input type='hidden' value='{{$loja->id}}'>
						</div>
					</div>
					</div>
				</div>
			@endforeach
		</div>
		<div class="col-sm-4">
			<h3>Novas Categorias</h3>
			@foreach($categorias as $categoria)
				@foreach($categoria->pecas as $peca)
					<div id="categoria{{$categoria->id}}" class="panel panel-default">
						<div class="panel-body">
							<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
						</div>
						<div class="panel-footer">
							<div class="row">
								<div class="col-sm-6">
									<a href="#" class="aprovar-categoria"><p class="text-left like-counter"><span class="fa fa-thumbs-up"></span> <strong>Sim</strong></p></a>
									<input class="valor" type='hidden' value='{{$categoria->id}}'>
								</div>
								<div class="col-sm-6">
									<a href="#" class="desaprovar-categoria"><p class="text-right like-counter"><span class="fa fa-thumbs-down"></span> <strong>Não</strong></p></a>
									<input class="valor" type='hidden' value='{{$categoria->id}}'>
								</div>
							</div>

							<hr>

							<h4>Peça: {{$peca->nome_peca}} 
								<p><small>Descrição: {{$peca->descricao_peca, 30}}</small></p>
								<p><small>Lojista: {{$peca->usuario->name}} </small></p>
								<small style="color:red">#{{$categoria->nome_categoria}} </small>
								@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $c)
									<small>#{{$c->nome_categoria}} </small>
								@endforeach
							</h4>

						</div>
					</div>
				@endforeach
			@endforeach
		</div>
		<div class="col-sm-4">
			<h3>Novas Peças</h3>
			@foreach($pecas as $peca)
				<div id="peca{{$peca->id}}" class="panel panel-default">
					<div class="panel-body">
						<img src="{{asset('img/'.$peca->foto->caminho_foto)}}" class="img-responsive">
					</div>
					<div class="panel-footer">
						<div class="row">
							<div class="col-sm-6">
								<a href="#" class="aprovar-peca"><p class="text-left like-counter"><span class="fa fa-thumbs-up"></span> <strong>Sim</strong></p></a>
								<input class="valor" type='hidden' value='{{$peca->id}}'>
							</div>
							<div class="col-sm-6">
								<a href="#" class="desaprovar-peca"><p class="text-right like-counter"><span class="fa fa-thumbs-down"></span> <strong>Não</strong></p></a>
								<input class="valor" type='hidden' value='{{$peca->id}}'>
							</div>
						</div>

						<hr>

						<h4>Peça: {{$peca->nome_peca}} 
							<p><small>Descrição: {{$peca->descricao_peca, 30}}</small></p>
							<p><small>Lojista: {{$peca->usuario->name}} </small></p>
							@foreach($peca->categorias()->where('nova_categoria', 0)->get() as $categoria)
								<small>#{{$categoria->nome_categoria}} </small>
							@endforeach
						</h4>

					</div>
				</div>
			@endforeach
		</div>
	</div>

@endsection