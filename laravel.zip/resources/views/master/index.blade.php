@extends('template_two')

@section('content')
	<p class="text-center" style="margin-top: 13px;"><span style="color: #E1E1E1;">───</span> <span class="pacifico" style="color: #1C1C1C;">Dashboard</span> <span style="color: #E1E1E1;">───</span></p><br />
	
	<div class="row">
		<div class="col-sm-3">
			<h3>Buscas por categoria</h3>
	        <ul>
			@foreach($categorias as $categoria)
				<li>{{$categoria->nome_categoria}}: {{count($categoria->buscas)}}</li>
			@endforeach
			</ul>
		</div>
		<div class="col-sm-3">
			<h3>Categoria x Cliente</h3>
	        <ul>
			@foreach($categorias as $categoria)
				<li>{{$categoria->nome_categoria}}</li>
				<ul>
					@foreach($categoria->users as $user)
						<li>{{$user->name}}</li>
					@endforeach
				</ul>
			@endforeach
			</ul>
		</div>
		<div class="col-sm-3">
			<h3>Cliente x Categoria</h3>
	        <ul>
			@foreach($users as $user)
				<li>{{$user->name}}</li>
				<ul>
					@foreach($user->categorias()->where('nova_categoria', 0)->get() as $categoria)
						<li>{{$categoria->nome_categoria}}</li>
					@endforeach
				</ul>
			@endforeach
			</ul>
		</div>
		<div class="col-sm-3">
			<h3>Busca por palavra</h3>
	        <ul>
			@foreach($users as $user)
				<li>{{$user->name}}</li>
				<ul>
					@foreach($user->buscas as $busca)
						<li>{{$busca->palavras_busca}}</li>
					@endforeach
				</ul>
			@endforeach
			</ul>
		</div>
	</div>

@endsection