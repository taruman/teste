<!DOCTYPE html>
<html lang="pt_BR">
<head>
	<!-- META -->
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
	<meta name="tags" content="moda, roupas, atacado, vendas, loja, varejo">
	<meta name="author" content="Sour Comunicação">

	<!-- TITLE & FAVICON -->
	<title>Fashion Finder</title>
	<link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">
	<link rel="apple-touch-icon" href="/img/favicon-apple-touch.png">
	<link rel="apple-touch-icon" sizes="72x72" href="/img/favicon-apple-touch-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="/img/favicon-apple-touch-114x114.png">

	<!-- LINK -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="/css/imports.css">
	<link rel="stylesheet" href="/css/normalize.css">
	<link rel="stylesheet" href="/css/fashionhunt-custom.css">

	<!-- SCRIPT -->
	<script src="https://code.jquery.com/jquery-2.1.4.min.js"></script>
	<script src="https://ajax.microsoft.com/ajax/jquery.templates/beta1/jquery.tmpl.min.js"></script>

</head>
<body>
	<!-- NAVBAR -->
	<nav class="navbar navbar-default navbar-fixed-top">
		<div class="container-fluid">
			<div class="container">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
						<span class="sr-only">Toggle navigation</span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</button>
					<a class="navbar-brand" href="{{action('PecasController@index')}}">Logo</a>
				</div>
				
				<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
					<ul class="nav navbar-nav navbar-right">
						<li><a href="{{action('PecasController@index')}}">Home</a></li>
						@if(!Auth::check())
						<li><a href="#" data-toggle="modal" data-target="#entrar" class="entrar">Entrar</a></li>
						<li><a href="#" data-toggle="modal" data-target="#registrar" class="registrar">Registrar-se</a></li>
						@else
							@if(Auth::user()->type == 2)
							<li><a href="{{url('lojista/create/pecas')}}">Nova Peça</a></li>
							<li><a href="{{action('PecasController@pecasLojista')}}">Minhas Peças</a></li>
							<li><a href="{{action('PecasController@dashboardLojista')}}">Dashboard</a></li>
							<li><a href="{{action('UsersController@contaLojista')}}">Conta</a></li>
							@endif
							@if(Auth::user()->type == 1)
							<li><a href="{{action('CategoriasController@create')}}">+Categorias</a></li>
							<li><a href="{{action('PecasController@solicitacoes')}}">Solicitações Pendentes</a></li>
							<li><a href="{{action('PecasController@dashboardMaster')}}">Relatórios</a></li>
							@endif
							@if(Auth::user()->type == 3)
							<li><a href="{{action('UsersController@contaCliente')}}">Conta</a></li>
							@endif
							<li><a href="{{action('UsersController@logout')}}">Sair</a></li>
						@endif
					</ul>
				</div>
			</div>
		</div>
	</nav>

	<!-- LOGIN & REGISTER -->
	<div class="modal fade" id="entrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" style="z-index: 9999; position: absolute;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-sm-12" style="margin-top: -40px">
							<h4 class="text-center">Entrar no FashionHunt</h4>
						</div>

						<div class="col-sm-12">
							<!--<span class="fa-block-social fa fa-facebook-official"></span>-->
							<input type="button" class="form-control" name="facebook-login" value="Entrar com Facebook">
							<p class="text-center" style="margin-top: 13px"><span style="color: #E1E1E1;">──────</span> <span class="pacifico" style="color: #1C1C1C;">Ou se preferir</span> <span style="color: #E1E1E1;">──────</span></p>
						</div>

						<form method="POST" name="logar" id="logar" action="{{ url('usuarios/login') }}">
							{!! csrf_field() !!}
							<div class="col-sm-12">
								<span class="fa-block-sec fa fa-user"></span><input type="text" name="email" id="login" class="form-control" placeholder="Login">
							</div>
							<div class="col-sm-12">
								<span class="fa-block fa fa-lock"></span><input type="password" name="password" id="senha" class="form-control" placeholder="Senha">
							</div>
							<div class="col-sm-12">
								<input type="submit" name="entrar" id="entrar" data-loading-text="Entrando..." autocomplete="off" class="btn btn-custom-login btn-block" value="Entrar">
							</div>
						</form>

						<div class="col-sm-12">
							<a href="#" class="forgot">esqueci minha senha</a>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-12">
								<p class="text-center" style=""><span class="pacifico" style="color: #1C1C1C;">Ainda não tem uma conta?</span></p>
							</div>	
							<input type="submit" class="btn btn-custom-register-o btn-block" value="Registre-se" data-toggle="modal" data-target="#registrar">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="modal fade" id="registrar" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" style="z-index: 9999; position: absolute;" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				</div>
				<div class="modal-header" style="padding: 0; margin-top: -30px;">
					<img src="http://placehold.it/400x250&text=Logo" class="img-responsive">
				</div>
				<div class="modal-body">
					<div class="row">
						<div class="col-sm-12">
							<p class="text-center"><span class="pacifico" style="color: #1C1C1C; font-size: 1.5em;">Selecione uma opção:</span> <p style="text-align: center; margin-top: -8px; font-size: 1.1em; color: #C1C1C1;"><small>Eu sou...</small></p></p>

							<a href="{{url('usuarios/register/lojista')}}" type="button" name="entrar" id="entrar" class="btn btn-custom-login btn-block">Lojista</a>

							<a href="{{url('usuarios/register/cliente')}}" type="button" name="entrar" id="entrar" class="btn btn-custom-distribuidor btn-block">Cliente</a>
						</div>
					</div>
				</div>
				<div class="modal-footer">
					<div class="row">
						<div class="col-sm-12">
							<div class="col-sm-12">
								<p class="text-center" style=""><span class="pacifico" style="color: #1C1C1C;">Já possuo uma conta</span></p>
							</div>	
							<input type="button" name="entrar" class="btn btn-custom-register btn-block" value="Entrar" data-toggle="modal" data-target="#entrar" class="entrar">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- PARALLAX SHOWCASE -->
	<div class="parallax-container-forms">
		<div class="parallax">
			<img src="http://www.knittingindustry.com/uploads/2062/Shima-Fashion_SHow-50th-2.gif">
		</div>
	</div>
	<br /><br />

	<!-- CONTENT -->

	<div class="container">

	@if(Session::has('sucesso'))
	    <div class="alert alert-success">
	        <h4>{{ Session::get('sucesso') }}</h4>
	    </div>
	@endif

	@if(Session::has('fracasso'))
	    <div class="alert alert-danger">
	        <h4>{{ Session::get('fracasso') }}</h4>
	    </div>
	@endif

	@yield('content')


	</div>

	<br /><br />
	<!-- ENDCONTENT -->

	<!-- FOOTER -->
	<footer class="footer">
		<div class="container">
			<p class="text-muted">&copy; Fashion Finder, 2015. | Todos os direitos reservados.</p>
		</div>
	</footer>

	<!-- SCRIPT -->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
	<script src="/js/progressive_loading.js"></script>
	<script src="/js/materialize.min.js"></script>
	<script src="/js/fwfunctions.js"></script>
	<script src="/js/nav-scroll.js"></script>
	<script src="/js/filter.js"></script>
	<!--<script>
		$(document).bind("contextmenu",function(e) {
     		e.preventDefault();
		});
	</script>-->
	<script type="text/javascript">
		$(document).ready( function() {

			//busca dos clientes
			var options = {
				valueNames: [ 'name' ]
			};
			var userList = new List('clients', options);

			//sugestão de nova categoria
			$('#outra_categoria').on('click', function(){
				$('#nova_categoria').toggle();
			});

			//lógica de aprovar categoria
			$(".aprovar-categoria").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/aprovar/categoria') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("aprovando categoria");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de desaprovar categoria
			$(".desaprovar-categoria").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/desaprovar/categoria') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("desaprovando categoria");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de aprovar peca
			$(".aprovar-peca").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/aprovar/peca') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("aprovando peca");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de desaprovar peca
			$(".desaprovar-peca").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/desaprovar/peca') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("desaprovando peca");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

//lógica de aprovar loja
			$(".aprovar-loja").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/aprovar/loja') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("aprovando loja");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});

			//lógica de desaprovar loja
			$(".desaprovar-loja").on("click", function(e){
				e.preventDefault();
				var id = $(this).parent().find('input:hidden').val();
				var url = "<?= url('master/solicitacoes/desaprovar/loja') ?>";
				var param = {"id":id};
				$.post(url, param, function(){
					console.log("desaprovando loja");
				}, "json")
				.done(function(data){
					$(data.id).fadeOut(1000, function(){
						$(this).remove();
					});
				})
				.fail(function(error){
					alert(error.statusText);
				});
			});
		});
	</script>
</body>
</html>