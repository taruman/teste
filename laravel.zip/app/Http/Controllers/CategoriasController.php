<?php

namespace FashionFinder\Http\Controllers;

use Illuminate\Http\Request;
use FashionFinder\Http\Requests\CategoriaRequest;
use FashionFinder\Http\Controllers\Controller;
use FashionFinder\Repositories\CategoriaRepository;

class CategoriasController extends Controller
{

    private $repository;

    public function __construct(CategoriaRepository $repository)
    {
        $this->repository = $repository;
    }

    public function index()
    {
        //
    }

    public function create()
    {
        return view('categorias.create');
    }

    public function store(CategoriaRequest $request)
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hoje = date('Y-m-d H:i:s');

        $data["nome_categoria"] = $request->input("nome_categoria");
        $data["nova_categoria"] = 0;
        $data["data_criacao_categoria"] = $hoje;
        $this->repository->create($data);
        return redirect()->action('PecasController@dashboardMaster')->withInput()->with('sucesso', 'Categoria gravada com sucesso');
    }

    public function show($id)
    {
        //
    }

    public function edit($id)
    {
        //
    }

    public function update(Request $request, $id)
    {
        //
    }

    public function destroy($id)
    {
        //
    }
}
