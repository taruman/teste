<?php

namespace FashionFinder\Http\Controllers;

use Illuminate\Http\Request;
use FashionFinder\Entities\User;
use FashionFinder\Entities\Cliente;
use FashionFinder\Entities\Lojista;
use FashionFinder\Http\Requests;
use FashionFinder\Http\Requests\ClienteRequest;
use FashionFinder\Http\Requests\LojistaRequest;
use FashionFinder\Http\Controllers\Controller;
use FashionFinder\Repositories\UserRepository;
use FashionFinder\Repositories\SeguidorRepository;
use Auth;

class UsersController extends Controller
{

    private $repository;
    private $repository_seguidor;

    public function __construct(UserRepository $repository, SeguidorRepository $repository_seguidor)
    {
        $this->repository = $repository;
        $this->repository_seguidor = $repository_seguidor;
    }

    public function confirma(Request $request)
    {
        $credenciais['email'] = $request->input('email');
        $credenciais['password'] = $request->input('password');
        if (Auth::attempt($credenciais))
        {
            return redirect()->action('PecasController@index')->withInput()->with('sucesso', 'Logado com sucesso');
        }
        else
        {
            return redirect()->action('PecasController@index')->withInput()->with('fracasso', 'Dados inválidos');
        }
    }

    public function login()
    {
        return view('usuarios.login');
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->action('PecasController@index')->withInput()->with('sucesso', 'Deslogado com sucesso.');
    }

    public function registerCliente()
    {
        return view('usuarios.register_cliente');
    }

    public function registerLojista()
    {
        return view('usuarios.register_lojista');
    }

    public function contaCliente()
    {
        $cliente = $this->repository->find(Auth::user()->id);
        return view('clientes.conta_cliente', compact('cliente'));
    }

    public function contaLojista()
    {
        $lojista = $this->repository->find(Auth::user()->id);
        return view('lojistas.conta_lojista', compact('lojista'));
    }

    public function editCliente(ClienteRequest $request)
    {
        $user = $this->repository->find(Auth::user()->id);
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->password = bcrypt($request->input('password'));
        $user->save();

        $cliente = $user->cliente;
        $cliente->doc_cliente = $request->input('doc');
        $cliente->endereco_cliente = $request->input('endereco');
        $cliente->cep_cliente = $request->input('cep');
        $cliente->telefone_cliente = $request->input('telefone');
        $cliente->instagram_cliente = $request->input('instagram');
        $cliente->facebook_cliente = $request->input('facebook');
        $cliente->save();

        return redirect()->action('UsersController@contaCliente')->withInput()->with('sucesso', 'Dados editados com sucesso');
    }

    public function editLojista(LojistaRequest $request)
    {
        $user = $this->repository->find(Auth::user()->id);
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->password = bcrypt($request->input('password'));
        $user->save();

        $lojista = $user->lojista;
        $lojista->cnpj_lojista = $request->input('doc');
        $lojista->endereco_lojista = $request->input('endereco');
        $lojista->cep_lojista = $request->input('cep');
        $lojista->telefone_lojista = $request->input('telefone');
        $lojista->instagram_lojista = $request->input('instagram');
        $lojista->facebook_lojista = $request->input('facebook');
        $lojista->site_lojista = $request->input('site');
        $lojista->save();

        return redirect()->action('UsersController@contaLojista')->withInput()->with('sucesso', 'Dados editados com sucesso');
    }

    public function seguir(Request $request)
    {
        $seguidor = $this->repository->find(Auth::user()->id);
        $seguido = $this->repository->find($request->input('id'));

        $seguidos = $this->repository_seguidor->findWhere(array('cliente_id' => $seguidor->cliente->id, 'lojista_id' => $seguido->lojista->id));
        
        if (count($seguidos) > 0) {
            $seguidos[0]->delete();
            $classe = ".seguidos".$seguido->id;
            $data = array('tipo' => 'desseguir', 'classe' => $classe);
            return json_encode($data);
        }
        else
        {
            date_default_timezone_set('America/Sao_Paulo');
            $hoje = date('Y-m-d H:i:s');

            $data['cliente_id'] = $seguidor->cliente->id;
            $data['lojista_id'] = $seguido->lojista->id;
            $data['data_criacao_seguidor'] = $hoje;
            $this->repository_seguidor->create($data);

            $classe = ".seguidos".$seguido->id;
            $data = array('tipo' => 'seguir', 'classe' => $classe);
            return json_encode($data);
        }
    }
}
