<?php

namespace FashionFinder\Http\Controllers\Auth;

use Illuminate\Http\Request;
use FashionFinder\Http\Requests\ClienteRequest;
use FashionFinder\Http\Requests\LojistaRequest;
use FashionFinder\Entities\User;
use FashionFinder\Entities\Cliente;
use FashionFinder\Entities\Lojista;
use Validator;
use FashionFinder\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    public function __construct()
    {
        $this->middleware('guest', ['except' => 'getLogout']);
    }

    protected function createLojista(LojistaRequest $request)
    {
        date_default_timezone_set('America/Sao_Paulo');

        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'type' => 2,
            'new_user' => 1,
            'password' => bcrypt($request->input('password')),
        ]);

        Lojista::create([
            'cnpj_lojista' => $request->input('doc'),
            'endereco_lojista' => $request->input('endereco'),
            'cep_lojista' => $request->input('cep'),
            'telefone_lojista' => $request->input('telefone'),
            'instagram_lojista' => $request->input('instagram'),
            'facebook_lojista' => $request->input('facebook'),
            'site_lojista' => $request->input('site'),
            'data_criacao_lojista' => date('Y-m-d H:i:s'),
            'user_id' => $user->id,
        ]);

        return redirect()->action('PecasController@index')->withInput()->with('sucesso', 'Lojista cadastrado com sucesso. Aguarde aprovação do administrador.');
    }

    protected function createCliente(ClienteRequest $request)
    {
        date_default_timezone_set('America/Sao_Paulo');

        $user = User::create([
            'name' => $request->input('name'),
            'email' => $request->input('email'),
            'type' => 3,
            'new_user' => 0,
            'password' => bcrypt($request->input('password')),
        ]);

        Cliente::create([
            'doc_cliente' => $request->input('doc'),
            'endereco_cliente' => $request->input('endereco'),
            'cep_cliente' => $request->input('cep'),
            'telefone_cliente' => $request->input('telefone'),
            'instagram_cliente' => $request->input('instagram'),
            'facebook_cliente' => $request->input('facebook'),
            'data_criacao_cliente' => date('Y-m-d H:i:s'),
            'user_id' => $user->id,
        ]);

        return redirect()->action('PecasController@index')->withInput()->with('sucesso', 'Cliente cadastrado com sucesso. Faça login para entrar.');
    }
}
