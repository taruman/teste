<?php

namespace FashionFinder\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use FashionFinder\Http\Requests\PecaRequest;
use FashionFinder\Entities\Peca;
use FashionFinder\Entities\Foto;
use FashionFinder\Entities\UserCategoria;
use FashionFinder\Http\Controllers\Controller;
use FashionFinder\Repositories\CategoriaRepository;
use FashionFinder\Repositories\PecaRepository;
use FashionFinder\Repositories\PecaCategoriaRepository;
use FashionFinder\Repositories\FotoRepository;
use FashionFinder\Repositories\CurtidaRepository;
use FashionFinder\Repositories\UserRepository;
use FashionFinder\Repositories\BuscaRepository;
use FashionFinder\Repositories\UserCategoriaRepository;
use Auth;
use Illuminate\Filesystem\Filesystem;
use Illuminate\Contracts\Filesystem\Factory as Storage;
use DateTime;
use DateInterval;

class PecasController extends Controller
{

    private $repository;
    private $repository_foto;
    private $repository_busca;
    private $repository_categoria;
    private $repository_peca_categoria;
    private $repository_user_categoria;
    private $repository_curtida;
    private $repository_user;
    private $filesystem;
    private $storage;


    public function __construct(UserCategoriaRepository $repository_user_categoria, UserRepository $repository_user, BuscaRepository $repository_busca, PecaRepository $repository, FotoRepository $repository_foto, CategoriaRepository $repository_categoria, PecaCategoriaRepository $repository_peca_categoria, CurtidaRepository $curtida, Storage $storage, Filesystem $filesystem)
    {
        $this->repository = $repository;
        $this->repository_busca = $repository_busca;
        $this->repository_foto = $repository_foto;
        $this->repository_categoria = $repository_categoria;
        $this->repository_peca_categoria = $repository_peca_categoria;
        $this->repository_user_categoria = $repository_user_categoria;
        $this->repository_curtida = $curtida;
        $this->repository_user = $repository_user;
        $this->storage = $storage;
        $this->filesystem = $filesystem;
    }

    public function index()
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hoje = date('Y-m-d');

        $d1 = DateTime::createFromFormat('Y-m-d',$hoje);
        $d2 = new DateInterval('P10D');
        $limite = $d1->sub($d2);
        $limite = $limite->format('Y-m-d');

        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $peca = new Peca();
        $pecas = $peca->where('nova_peca', 0)
                      ->where('data_criacao_peca', '>=', $limite)
                      ->orderBy('curtidas_peca', 'desc')
                      ->with(['categorias', 'usuario', 'foto', 'usuarios'])
                      ->paginate(12);

        return view('pecas.index', compact('pecas', 'categorias', 'lojas'));
    }

    public function populares()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $pecas = $this->repository->scopeQuery(function($query){
            return $query->orderBy('curtidas_peca', 'desc')->where('nova_peca', 0);
        })->paginate(12);
        return view('pecas.index', compact('pecas', 'categorias', 'lojas'));
    }

    public function favoritos()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $user = $this->repository_user->find(Auth::user()->id);
        $lojistas = array();
        foreach ($user->cliente->seguidos as $lojista) {
            $lojistas[] = $lojista->user->id;
        }
        $peca = new Peca();
        $pecas = $peca
                      ->where('nova_peca', 0)
                      ->whereIn('user_id', $lojistas)
                      ->paginate(12);
        return view('pecas.index', compact('pecas', 'categorias', 'lojas'));
    }

    public function curtidas()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $user = $this->repository_user->find(Auth::user()->id);
        $pecas = $user->pecas_curtidas()->where('nova_peca', 0)->paginate(12);
        return view('pecas.index', compact('pecas', 'categorias', 'lojas'));
    }

    public function recente()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $pecas = $this->repository->scopeQuery(function($query){
            return $query->orderBy('data_criacao_peca', 'desc')->where('nova_peca', 0);
        })->paginate(12);
        return view('pecas.index', compact('pecas', 'categorias', 'lojas'));        
    }

    public function lojistas()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $usuarios = $this->repository_user->scopeQuery(function($query){
            return $query->orderBy('name', 'asc');
        })->paginate(12);
        return view('lojistas.lista', compact('usuarios', 'categorias', 'lojas'));      
    }

    public function pecasLojista()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $user = $this->repository_user->find(Auth::user()->id);
        $pecas = $user->pecas()->where('nova_peca', 0)->paginate(12);
        return view('lojistas.pecas_lojista', compact('pecas', 'categorias', 'lojas'));
    }

    public function create()
    {
        $categorias = $this->repository_categoria->findByField('nova_categoria', 0);
        return view('pecas.create', compact('categorias'));
    }

    public function store(PecaRequest $request)
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hoje = date('Y-m-d H:i:s');

        //grava peça
        $peca['nome_peca'] = $request->input('nome_peca');
        $peca['descricao_peca'] = $request->input('descricao_peca');
        $peca['codigo_peca'] = $request->input('codigo_peca');
        $peca['data_criacao_peca'] = $hoje;
        $peca['nova_peca'] = 1;
        $peca['user_id'] = Auth::user()->id;
        $peca_gravada = $this->repository->create($peca);

        //grava nova categoria, se houver
        $nova_categoria = $request->input('nova_categoria');
        if (!empty($nova_categoria)) 
        {
           $categoria['nome_categoria'] = $request->input('nova_categoria');
           $categoria['nova_categoria'] = 1;
           $categoria['data_criacao_categoria'] = $hoje;
           $categoria_gravada = $this->repository_categoria->create($categoria);

           $categorias['peca_id'] = $peca_gravada->id;
           $categorias['categoria_id'] = $categoria_gravada->id;
           $this->repository_peca_categoria->create($categorias);
        }

        //grava categorias
        $categorias_id = $request->input('categorias');
        foreach ($categorias_id as $categoria_id) {
           $categorias['peca_id'] = $peca_gravada->id;
           $categorias['categoria_id'] = $categoria_id;
           $this->repository_peca_categoria->create($categorias);
        };

        //salvar imagens no banco
        $file = $request->file("foto");
        $extension = $file->getClientOriginalExtension();

        $data["extensao_foto"] = $extension;
        $data["nome_foto"] = $peca_gravada->id;
        $data["peca_id"] = $peca_gravada->id;
        $data['caminho_foto'] = $peca_gravada->id.".".$extension;
        $peca_file = $peca_gravada->foto()->create($data);
        
        //salva imagens no diretório
        $this->storage->put($peca_file->id.".".$data["extensao_foto"], $this->filesystem->get($file));      

        return redirect()->action('PecasController@index')->withInput()->with('sucesso', 'Peça gravada com sucesso. Aguarde a aprovação do administrador');
    }

    public function dashboardMaster()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $users = $this->repository_user->all();

        return view('master.index', compact('users', 'categorias'));
    }

    public function dashboardLojista()
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hoje = date('Y-m-d');

        $d1 = DateTime::createFromFormat('Y-m-d',$hoje);
        $d2 = new DateInterval('P3M');
        $limite = $d1->sub($d2);
        $limite = $limite->format('Y-m-d');

        $user = $this->repository_user->find(Auth::user()->id);

        //saber quantas peças foram curtidas
        $ps = $user->pecas()->where('nova_peca', 0)->with(['curtidas'])->get();
        $pecas_curtidas = 0;
        foreach ($ps as $p) 
        {
            if(count($p->curtidas) > 0)
            {
                $curtiu = false;
                foreach ($p->curtidas as $curtida) 
                {
                    if ($curtida->data_criacao_curtida >= $limite) 
                    {
                        $curtiu = true;
                    }
                }
                if ($curtiu) 
                {
                    $pecas_curtidas += 1;
                }
            }
        }

        //saber quais usuários curtiram as peças
        $pecas = $user->pecas()->where('nova_peca', 0)->with(['usuarios'])->get();
        $users = array();
        foreach ($pecas as $peca) 
        {
            if (count($peca->usuarios) > 0) 
            {
                foreach ($peca->usuarios as $usuario) 
                {
                    $u["nome"] = $usuario->name;
                    $u["email"] = $usuario->email;
                    if (!in_array($u, $users)) 
                    {
                        $users[] = $u;
                    }
                }
            }
        }

        return view('lojistas.index', compact('users', 'pecas_curtidas'));
    }

    public function solicitacoes()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 1);
        $pecas = $this->repository->findByField("nova_peca", 1);
        $lojas = $this->repository_user->findWhere(array('type' => 2, 'new_user' => 1));

        return view('master.solicitacoes', compact('pecas', 'categorias', 'lojas'));
    }

    public function buscaCategoria()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $cat = $this->repository_categoria->find(Input::get("id"));
        $pecas = $cat->pecas()->where('nova_peca', 0)->get();

        //persistindo a busca quando user está logado
        if (Auth::check() && Auth::user()->type == 3) 
        {
            date_default_timezone_set('America/Sao_Paulo');
            $agora = date('Y-m-d H:i:s');

            $data['user_id'] = Auth::user()->id;
            $data['categoria_id'] = $cat->id;
            $data['data_criacao_busca_categoria'] = $agora;
            $this->repository_user_categoria->create($data);
        }

        return view('pecas.busca', compact('pecas', 'categorias', 'lojas'));

    }

    public function buscaLoja()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $user = $this->repository_user->find(Input::get("id"));
        $pecas = $user->pecas()->where('nova_peca', 0)->get();

        return view('pecas.busca', compact('pecas', 'categorias', 'lojas'));

    }

    public function busca()
    {
        $categorias = $this->repository_categoria->findByField("nova_categoria", 0);
        $lojas = $this->repository_user->findByField('type', 2);
        $palavra = Input::get("palavras");
        $palavras = explode(" ", $palavra);
        $peca = new Peca();
        $pecas = $peca->where('nova_peca', 0)
                      ->where(function($query) use ($palavras) {
                         foreach ($palavras as $p) {
                             $query->orWhere("descricao_peca", "LIKE", "%$p%");
                         }
                      })->get();

        //persistindo a busca quando user está logado
        if (Auth::check() && Auth::user()->type == 3) 
        {
            date_default_timezone_set('America/Sao_Paulo');
            $agora = date('Y-m-d H:i:s');

            $data['user_id'] = Auth::user()->id;
            $data["palavras_busca"] = $palavra;
            $data["data_criacao_busca"] = $agora;
            $this->repository_busca->create($data);
        }

        return view('pecas.busca', compact('pecas', 'categorias', 'lojas'));
    }

    public function curtir($id)
    {
        $curtida = $this->repository_curtida->findWhere(array('user_id' => Auth::user()->id, 'peca_id' => $id));
        
        if (count($curtida) > 0) {
            $curtida[0]->delete();
            $id = "#".$id;
            $data = array('tipo' => 'descurtir', 'id' => $id);
            return json_encode($data);
        }
        else
        {
            date_default_timezone_set('America/Sao_Paulo');
            $hoje = date('Y-m-d H:i:s');

            $data['peca_id'] = $id;
            $data['user_id'] = Auth::user()->id;
            $data['data_criacao_curtida'] = $hoje;
            $this->repository_curtida->create($data);

            $peca = $this->repository->find($id);
            $curtidas = $peca->curtidas_peca;
            $total = $curtidas + 1;
            $peca->curtidas_peca = $total;
            $peca->save();
            $id = "#".$id;
            $data = array('tipo' => 'curtir', 'id' => $id, 'total' => $total);
            return json_encode($data);
        }

    }

    public function aprovarCategoria(Request $request)
    {
        $categoria = $this->repository_categoria->find($request->input("id"));
        $categoria->nova_categoria = 0;
        $categoria->save();
        $id = "#categoria".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function desaprovarCategoria(Request $request)
    {
        $categoria_id = $request->input("id");

        $categoria = $this->repository_categoria->find($categoria_id);
        $categoria->buscas()->delete();
        $categoria->peca_categorias()->delete();

        $this->repository_categoria->delete($categoria_id);

        $id = "#categoria".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function aprovarPeca(Request $request)
    {
        date_default_timezone_set('America/Sao_Paulo');
        $hoje = date('Y-m-d H:i:s');
        $peca = $this->repository->find($request->input("id"));
        $peca->nova_peca = 0;
        $peca->data_criacao_peca = $hoje;
        $peca->save();
        $id = "#peca".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function desaprovarPeca(Request $request)
    {
        $peca_id = $request->input("id");

        $peca = $this->repository->find($peca_id);
        $peca->foto()->delete();
        $peca->peca_categorias()->delete();
        $peca->curtidas()->delete();

        $this->repository->delete($peca_id);

        $id = "#peca".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function aprovarLoja(Request $request)
    {
        $loja = $this->repository_user->find($request->input("id"));
        $loja->new_user = 0;
        $loja->save();
        $id = "#loja".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function desaprovarLoja(Request $request)
    {
        $user_id = $request->input("id");

        $user = $this->repository_user->find($user_id);
        $user->lojista()->delete();

        $this->repository_user->delete($user_id);

        $id = "#loja".$request->input("id");
        $data = array('id' => $id);
        return json_encode($data);
    }

    public function delete(Request $request)
    {
        $peca_id = $request->input("id");

        //verifica se a peça é do user logado
        $result = $this->repository->findWhere(array("id" => $peca_id, "user_id" => Auth::user()->id));

        if (count($result) <= 0) 
        {
            $id = "#peca".$request->input("id");
            $data = array('id' => $id, 'tipo' => 'fracasso');
            return json_encode($data);
        }

        $peca = $this->repository->find($peca_id);
        $peca->foto()->delete();
        $peca->peca_categorias()->delete();
        $peca->curtidas()->delete();

        $this->repository->delete($peca_id);

        $id = "#peca".$request->input("id");
        $data = array('id' => $id, 'tipo' => 'sucesso');
        return json_encode($data);
    }
}
