<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::get('/', ['uses' => 'PecasController@index']);
Route::get('home', ['as' => 'home', 'uses' => 'PecasController@index']);

Route::get('pecas/recente', ['as' => 'pecas.recente', 'uses' => 'PecasController@recente']);
Route::get('pecas/lojistas', ['as' => 'pecas.lojistas', 'uses' => 'PecasController@lojistas']);
Route::get('pecas/populares', ['as' => 'pecas.populares', 'uses' => 'PecasController@populares']);
Route::get('pecas/busca/categoria', ['as' => 'pecas.busca.categoria', 'uses' => 'PecasController@buscaCategoria']);
Route::get('pecas/busca/loja', ['as' => 'pecas.busca.loja', 'uses' => 'PecasController@buscaLoja']);
Route::get('pecas/busca', ['as' => 'pecas.busca', 'uses' => 'PecasController@busca']);

Route::get('usuarios/register/lojista', ['as' => 'usuarios.register.lojista', 'uses' => 'UsersController@registerLojista']);
Route::post('usuarios/register/lojista', ['as' => 'usuarios.create.lojista', 'uses' => 'Auth\AuthController@createLojista']);
Route::get('usuarios/register/cliente', ['as' => 'usuarios.register.cliente', 'uses' => 'UsersController@registerCliente']);
Route::post('usuarios/register/cliente', ['as' => 'usuarios.create.cliente', 'uses' => 'Auth\AuthController@createCliente']);
Route::get('usuarios/login', ['as' => 'usuarios.login', 'uses' => 'UsersController@login']);
Route::post('usuarios/login', ['as' => 'usuarios.confirma', 'uses' => 'UsersController@confirma']);
Route::get('usuarios/logout', ['as' => 'usuarios.logout', 'uses' => 'UsersController@logout']);

Route::group(['middleware' => 'cliente'], function(){
	Route::get('pecas/curtir/{id}', ['as' => 'pecas.curtir', 'uses' => 'PecasController@curtir']);
	Route::post('cliente/seguir', ['as' => 'cliente.seguir', 'uses' => 'UsersController@seguir']);
	Route::get('pecas/favoritos', ['as' => 'pecas.favoritos', 'uses' => 'PecasController@favoritos']);
	Route::get('pecas/curtidas', ['as' => 'pecas.curtidas', 'uses' => 'PecasController@curtidas']);
	Route::get('cliente/conta', ['as' => 'cliente.conta', 'uses' => 'UsersController@contaCliente']);
	Route::post('cliente/edit', ['as' => 'cliente.edit', 'uses' => 'UsersController@editCliente']);
});

Route::group(['middleware' => 'lojista'], function(){
	Route::get('lojista/dashboard', ['as' => 'lojista.dashboard', 'uses' => 'PecasController@dashboardLojista']);
	Route::get('lojista/pecas', ['as' => 'lojista.pecas', 'uses' => 'PecasController@pecasLojista']);
	Route::get('lojista/create/pecas', ['as' => 'lojista.create.pecas', 'uses' => 'PecasController@create']);
	Route::get('lojista/conta', ['as' => 'lojista.conta', 'uses' => 'UsersController@contaLojista']);
	Route::post('lojista/create/pecas', ['as' => 'lojista.store.pecas', 'uses' => 'PecasController@store']);
	Route::post('lojista/delete/pecas', ['as' => 'lojista.delete.pecas', 'uses' => 'PecasController@delete']);
	Route::post('lojista/edit', ['as' => 'lojista.edit', 'uses' => 'UsersController@editLojista']);
});

Route::group(['middleware' => 'master'], function(){
	Route::get('master/dashboard', ['as' => 'master.dashboard', 'uses' => 'PecasController@dashboardMaster']);
	Route::get('master/solicitacoes', ['as' => 'master.solicitacoes', 'uses' => 'PecasController@solicitacoes']);
	Route::post('master/solicitacoes/aprovar/peca', ['as' => 'master.solicitacoes.aprovar.peca', 'uses' => 'PecasController@aprovarPeca']);
	Route::post('master/solicitacoes/desaprovar/peca', ['as' => 'master.solicitacoes.desaprovar.peca', 'uses' => 'PecasController@desaprovarPeca']);
	Route::post('master/solicitacoes/aprovar/categoria', ['as' => 'master.solicitacoes.aprovar.categoria', 'uses' => 'PecasController@aprovarCategoria']);
	Route::post('master/solicitacoes/desaprovar/categoria', ['as' => 'master.solicitacoes.desaprovar.categoria', 'uses' => 'PecasController@desaprovarCategoria']);
	Route::post('master/solicitacoes/aprovar/loja', ['as' => 'master.solicitacoes.aprovar.loja', 'uses' => 'PecasController@aprovarLoja']);
	Route::post('master/solicitacoes/desaprovar/loja', ['as' => 'master.solicitacoes.desaprovar.loja', 'uses' => 'PecasController@desaprovarLoja']);
	Route::get('master/create/categoria', ['as' => 'master.create.categoria', 'uses' => 'CategoriasController@create']);
	Route::post('master/create/categoria', ['as' => 'master.store.categoria', 'uses' => 'CategoriasController@store']);	
});


