<?php

namespace FashionFinder\Http\Middleware;

use Illuminate\Foundation\Http\Middleware\VerifyCsrfToken as BaseVerifier;

class VerifyCsrfToken extends BaseVerifier
{
    /**
     * The URIs that should be excluded from CSRF verification.
     *
     * @var array
     */
    protected $except = [
        'master/solicitacoes/aprovar/peca',
        'master/solicitacoes/desaprovar/peca',
        'master/solicitacoes/aprovar/categoria',
        'master/solicitacoes/desaprovar/categoria',
        'master/solicitacoes/aprovar/loja',
        'master/solicitacoes/desaprovar/loja',
        'lojista/delete/pecas',
        'cliente/seguir',
    ];
}
