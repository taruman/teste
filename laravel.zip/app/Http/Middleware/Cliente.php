<?php

namespace FashionFinder\Http\Middleware;
use Auth;

use Closure;

class Cliente
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check() || Auth::user()->type != 3) {
            return redirect()->action('PecasController@index')->withInput()->with('fracasso', 'Sem permissão!');
        }

        return $next($request);
    }
}
