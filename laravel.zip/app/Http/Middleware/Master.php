<?php

namespace FashionFinder\Http\Middleware;

use Closure;
use Auth;

class Master
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (!Auth::check() || Auth::user()->type != 1) {
            return redirect()->action('PecasController@index')->withInput()->with('fracasso', 'Sem permissão!');
        }

        return $next($request);
    }
}
