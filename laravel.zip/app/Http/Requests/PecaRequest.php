<?php

namespace FashionFinder\Http\Requests;

use FashionFinder\Http\Requests\Request;

class PecaRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'nome_peca' => 'required',
            'descricao_peca' => 'required',
            'codigo_peca' => 'required',
            'categorias' => 'required',
            'foto' => 'required',
        ];
    }
}
