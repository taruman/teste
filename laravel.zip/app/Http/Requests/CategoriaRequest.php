<?php

namespace FashionFinder\Http\Requests;

use FashionFinder\Http\Requests\Request;

class CategoriaRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'nome_categoria' => 'required',
        ];
    }
}
