<?php

namespace FashionFinder\Http\Requests;

use FashionFinder\Http\Requests\Request;

class ClienteRequest extends Request
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255',
            'password' => 'required|min:6',
        ];
    }

    /*public function messages()
    {

    }*/
}
