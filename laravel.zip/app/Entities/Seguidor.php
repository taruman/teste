<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Seguidor extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['cliente_id', 'lojista_id', 'data_criacao_seguidor'];
    protected $table = 'seguidores';
    public $timestamps = false;

}
