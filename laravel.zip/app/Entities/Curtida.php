<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Curtida extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['user_id', 'peca_id', 'data_criacao_curtida'];
    protected $table = 'curtidas';
    public $timestamps = false;

    public function peca()
    {
    	return $this->belongsTo(Peca::class, 'peca_id', 'id');
    }

    public function user()
    {
    	return $this->belongsTo(User::class, 'user_id', 'id');
    }
}
