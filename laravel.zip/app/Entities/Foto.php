<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Foto extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['nome_foto', 'extensao_foto', 'caminho_foto', 'peca_id'];
    protected $table = 'fotos';
    public $timestamps = false;

    public function peca() {
        return $this->hasOne(Peca::class, 'peca_id', 'id');
    }

}
