<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class PecaCategoria extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['peca_id', 'categoria_id'];
    protected $table = 'peca_categorias';
    public $timestamps = false;

}
