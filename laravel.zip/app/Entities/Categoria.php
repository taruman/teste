<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Categoria extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['nome_categoria', 'nova_categoria', 'data_criacao_categoria'];
    protected $table = 'categorias';
    public $timestamps = false;

    public function pecas()
    {
    	return $this->belongsToMany(Peca::class, 'peca_categorias', 'categoria_id', 'peca_id');
    }

    public function users()
    {
    	return $this->belongsToMany(User::class, 'user_categorias', 'categoria_id', 'user_id');
    }

    public function buscas() 
    {
        return $this->hasMany(UserCategoria::class, 'categoria_id', 'id');
    } 

    public function peca_categorias() 
    {
        return $this->hasMany(PecaCategoria::class, 'categoria_id', 'id');
    } 

}
