<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Cliente extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['doc_cliente', 'endereco_cliente', 'cep_cliente', 'telefone_cliente', 'instagram_cliente', 'facebook_cliente', 'data_criacao_cliente', 'user_id'];
    protected $table = 'clientes';
    public $timestamps = false;

    public function user() {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function seguidos() {
        return $this->belongsToMany(Lojista::class, 'seguidores', 'cliente_id', 'lojista_id');
    }

}
