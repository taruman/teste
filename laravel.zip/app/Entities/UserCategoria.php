<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class UserCategoria extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['user_id', 'categoria_id', 'data_criacao_busca_categoria'];
    protected $table = 'user_categorias';
    public $timestamps = false;

}
