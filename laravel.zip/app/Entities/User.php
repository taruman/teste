<?php

namespace FashionFinder\Entities;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class User extends Model implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract,
                                    Transformable
{
    use Authenticatable, Authorizable, CanResetPassword, TransformableTrait;

    protected $table = 'users';
    protected $fillable = ['name', 'email', 'type', 'new_user', 'password'];
    protected $hidden = ['password', 'remember_token'];

    public function pecas() {
        return $this->hasMany(Peca::class, 'user_id', 'id');
    } 

    public function cliente() {
        return $this->hasOne(Cliente::class, 'user_id', 'id');
    }

    public function lojista() {
        return $this->hasOne(Lojista::class, 'user_id', 'id');
    }

    public function pecas_curtidas() {
        return $this->belongsToMany(Peca::class, 'curtidas', 'user_id', 'peca_id');
    }

    public function categorias() {
        return $this->belongsToMany(Categoria::class, 'user_categorias', 'user_id', 'categoria_id');
    }

    public function curtidas() {
        return $this->hasMany(Curtida::class, 'user_id', 'id');
    } 

    public function buscas() {
        return $this->hasMany(Busca::class, 'user_id', 'id');
    } 
}