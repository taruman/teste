<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Peca extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['nome_peca', 'descricao_peca', 'codigo_peca', 'data_criacao_peca', 'nova_peca', 'user_id', 'curtidas_peca'];
    protected $table = 'pecas';
    public $timestamps = false;

    public function usuario()
    {
    	return $this->belongsTo(User::class, 'user_id', 'id');
    }

    public function categorias()
    {
    	return $this->belongsToMany(Categoria::class, 'peca_categorias', 'peca_id', 'categoria_id');
    }

    public function usuarios() {
        return $this->belongsToMany(User::class, 'curtidas', 'peca_id', 'user_id');
    } 

    public function foto() {
        return $this->hasOne(Foto::class, 'peca_id', 'id');
    }

    public function curtidas() {
        return $this->hasMany(Curtida::class, 'peca_id', 'id');
    } 

    public function peca_categorias() {
        return $this->hasMany(PecaCategoria::class, 'peca_id', 'id');
    } 

}
