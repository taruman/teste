<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Lojista extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['cnpj_lojista', 'site_lojista', 'endereco_lojista', 'cep_lojista', 'telefone_lojista', 'instagram_lojista', 'facebook_lojista', 'data_criacao_lojista', 'user_id'];
    protected $table = 'lojistas';
    public $timestamps = false;

    public function user() {
        return $this->hasOne(User::class, 'id', 'user_id');
    }

    public function seguidores() {
        return $this->belongsToMany(Cliente::class, 'seguidores', 'lojista_id', 'cliente_id');
    }

}
