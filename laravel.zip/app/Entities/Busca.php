<?php

namespace FashionFinder\Entities;

use Illuminate\Database\Eloquent\Model;
use Prettus\Repository\Contracts\Transformable;
use Prettus\Repository\Traits\TransformableTrait;

class Busca extends Model implements Transformable
{
    use TransformableTrait;

    protected $fillable = ['palavras_busca', 'data_criacao_busca', 'user_id'];
    protected $table = 'buscas';
    public $timestamps = false;

}
