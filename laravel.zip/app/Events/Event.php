<?php

namespace FashionFinder\Events;

abstract class Event
{
    //
}
