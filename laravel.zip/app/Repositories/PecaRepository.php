<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PecaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface PecaRepository extends RepositoryInterface
{
    //
}
