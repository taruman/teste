<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface FotoRepository
 * @package namespace FashionFinder\Repositories;
 */
interface FotoRepository extends RepositoryInterface
{
    //
}
