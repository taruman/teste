<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CategoriaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface CategoriaRepository extends RepositoryInterface
{
    //
}
