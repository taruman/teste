<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository
 * @package namespace FashionFinder\Repositories;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
