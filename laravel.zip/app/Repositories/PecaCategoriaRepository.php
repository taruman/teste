<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PecaCategoriaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface PecaCategoriaRepository extends RepositoryInterface
{
    //
}
