<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface LojistaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface LojistaRepository extends RepositoryInterface
{
    //
}
