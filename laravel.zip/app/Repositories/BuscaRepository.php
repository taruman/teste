<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface BuscaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface BuscaRepository extends RepositoryInterface
{
    //
}
