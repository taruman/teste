<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CurtidaRepository
 * @package namespace FashionFinder\Repositories;
 */
interface CurtidaRepository extends RepositoryInterface
{
    //
}
