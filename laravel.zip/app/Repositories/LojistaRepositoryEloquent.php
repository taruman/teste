<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use FashionFinder\Repositories\LojistaRepository;
use FashionFinder\Entities\Lojista;

/**
 * Class LojistaRepositoryEloquent
 * @package namespace FashionFinder\Repositories;
 */
class LojistaRepositoryEloquent extends BaseRepository implements LojistaRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Lojista::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
