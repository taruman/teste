<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use FashionFinder\Repositories\PecaRepository;
use FashionFinder\Entities\Peca;

/**
 * Class PecaRepositoryEloquent
 * @package namespace FashionFinder\Repositories;
 */
class PecaRepositoryEloquent extends BaseRepository implements PecaRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Peca::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
