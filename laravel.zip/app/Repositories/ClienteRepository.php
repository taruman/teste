<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ClienteRepository
 * @package namespace FashionFinder\Repositories;
 */
interface ClienteRepository extends RepositoryInterface
{
    //
}
