<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use FashionFinder\Repositories\CurtidaRepository;
use FashionFinder\Entities\Curtida;

/**
 * Class CurtidaRepositoryEloquent
 * @package namespace FashionFinder\Repositories;
 */
class CurtidaRepositoryEloquent extends BaseRepository implements CurtidaRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Curtida::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
