<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use FashionFinder\Repositories\BuscaRepository;
use FashionFinder\Entities\Busca;

/**
 * Class BuscaRepositoryEloquent
 * @package namespace FashionFinder\Repositories;
 */
class BuscaRepositoryEloquent extends BaseRepository implements BuscaRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return Busca::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
