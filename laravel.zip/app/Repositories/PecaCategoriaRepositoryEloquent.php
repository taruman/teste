<?php

namespace FashionFinder\Repositories;

use Prettus\Repository\Eloquent\BaseRepository;
use Prettus\Repository\Criteria\RequestCriteria;
use FashionFinder\Repositories\PecaCategoriaRepository;
use FashionFinder\Entities\PecaCategoria;

/**
 * Class PecaCategoriaRepositoryEloquent
 * @package namespace FashionFinder\Repositories;
 */
class PecaCategoriaRepositoryEloquent extends BaseRepository implements PecaCategoriaRepository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return PecaCategoria::class;
    }

    /**
     * Boot up the repository, pushing criteria
     */
    public function boot()
    {
        $this->pushCriteria(app(RequestCriteria::class));
    }
}
