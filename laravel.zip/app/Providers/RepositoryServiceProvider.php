<?php

namespace FashionFinder\Providers;

use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap the application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    /**
     * Register the application services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(
            'FashionFinder\Repositories\TipoRepository',
            'FashionFinder\Repositories\TipoRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\UserRepository',
            'FashionFinder\Repositories\UserRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\SeguidorRepository',
            'FashionFinder\Repositories\SeguidorRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\PecaRepository',
            'FashionFinder\Repositories\PecaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\PecaCategoriaRepository',
            'FashionFinder\Repositories\PecaCategoriaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\LojistaRepository',
            'FashionFinder\Repositories\LojistaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\FotoRepository',
            'FashionFinder\Repositories\FotoRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\CurtidaRepository',
            'FashionFinder\Repositories\CurtidaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\ClienteRepository',
            'FashionFinder\Repositories\ClienteRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\CategoriaRepository',
            'FashionFinder\Repositories\CategoriaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\BuscaRepository',
            'FashionFinder\Repositories\BuscaRepositoryEloquent'
        );

        $this->app->bind(
            'FashionFinder\Repositories\UserCategoriaRepository',
            'FashionFinder\Repositories\UserCategoriaRepositoryEloquent'
        );
    }
}
