-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: fashionfinder
-- ------------------------------------------------------
-- Server version	5.6.25

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `buscas`
--

DROP TABLE IF EXISTS `buscas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `buscas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `palavras_busca` varchar(255) NOT NULL,
  `data_criacao_busca` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `buscas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `buscas`
--

LOCK TABLES `buscas` WRITE;
/*!40000 ALTER TABLE `buscas` DISABLE KEYS */;
/*!40000 ALTER TABLE `buscas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_categoria` varchar(255) NOT NULL,
  `nova_categoria` tinyint(1) NOT NULL DEFAULT '1',
  `data_criacao_categoria` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'festas',0,'2015-10-27 03:30:49'),(2,'esporte',0,'2015-10-27 03:30:54'),(3,'social',0,'2015-10-27 03:31:00'),(4,'descolado',0,'2015-10-27 03:31:05'),(5,'gordinhas',0,'2015-10-27 03:31:11'),(7,'magrinhas',1,'2015-10-27 04:02:55');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_cliente` varchar(255) DEFAULT NULL,
  `endereco_cliente` varchar(255) DEFAULT NULL,
  `cep_cliente` varchar(255) DEFAULT NULL,
  `telefone_cliente` varchar(255) DEFAULT NULL,
  `instagram_cliente` varchar(255) DEFAULT NULL,
  `facebook_cliente` varchar(255) DEFAULT NULL,
  `data_criacao_cliente` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (2,'','','06767140','','','','2015-10-27 03:27:59',2);
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `curtidas`
--

DROP TABLE IF EXISTS `curtidas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `curtidas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_criacao_curtida` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `peca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `peca_id` (`peca_id`),
  CONSTRAINT `curtidas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `curtidas_ibfk_2` FOREIGN KEY (`peca_id`) REFERENCES `pecas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `curtidas`
--

LOCK TABLES `curtidas` WRITE;
/*!40000 ALTER TABLE `curtidas` DISABLE KEYS */;
/*!40000 ALTER TABLE `curtidas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fotos`
--

DROP TABLE IF EXISTS `fotos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fotos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_foto` varchar(255) NOT NULL,
  `extensao_foto` varchar(255) NOT NULL,
  `caminho_foto` varchar(255) NOT NULL,
  `peca_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `peca_id` (`peca_id`),
  CONSTRAINT `fotos_ibfk_1` FOREIGN KEY (`peca_id`) REFERENCES `pecas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fotos`
--

LOCK TABLES `fotos` WRITE;
/*!40000 ALTER TABLE `fotos` DISABLE KEYS */;
INSERT INTO `fotos` VALUES (1,'1','jpg','1.jpg',1),(2,'2','jpg','2.jpg',2);
/*!40000 ALTER TABLE `fotos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lojistas`
--

DROP TABLE IF EXISTS `lojistas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lojistas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cnpj_lojista` varchar(255) DEFAULT NULL,
  `endereco_lojista` varchar(255) DEFAULT NULL,
  `cep_lojista` varchar(255) DEFAULT NULL,
  `telefone_lojista` varchar(255) DEFAULT NULL,
  `instagram_lojista` varchar(255) DEFAULT NULL,
  `facebook_lojista` varchar(255) DEFAULT NULL,
  `site_lojista` varchar(255) DEFAULT NULL,
  `data_criacao_lojista` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `lojistas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lojistas`
--

LOCK TABLES `lojistas` WRITE;
/*!40000 ALTER TABLE `lojistas` DISABLE KEYS */;
INSERT INTO `lojistas` VALUES (1,'','','064798414','','','','','2015-10-27 03:28:31',3),(3,'cnpj tng','endereço tng','cep tng','telefone tng','insta tng','face tng','www.tng.com.br','2015-10-27 03:44:12',5),(4,'','','','','','','','2015-10-27 04:01:53',6);
/*!40000 ALTER TABLE `lojistas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `peca_categorias`
--

DROP TABLE IF EXISTS `peca_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `peca_categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `peca_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `peca_id` (`peca_id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `peca_categorias_ibfk_1` FOREIGN KEY (`peca_id`) REFERENCES `pecas` (`id`),
  CONSTRAINT `peca_categorias_ibfk_2` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `peca_categorias`
--

LOCK TABLES `peca_categorias` WRITE;
/*!40000 ALTER TABLE `peca_categorias` DISABLE KEYS */;
INSERT INTO `peca_categorias` VALUES (2,1,4),(3,1,5),(4,2,7),(5,2,4);
/*!40000 ALTER TABLE `peca_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pecas`
--

DROP TABLE IF EXISTS `pecas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pecas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_peca` varchar(255) NOT NULL,
  `descricao_peca` text NOT NULL,
  `codigo_peca` varchar(255) NOT NULL,
  `nova_peca` tinyint(1) NOT NULL DEFAULT '1',
  `curtidas_peca` int(11) NOT NULL DEFAULT '0',
  `data_criacao_peca` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `pecas_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pecas`
--

LOCK TABLES `pecas` WRITE;
/*!40000 ALTER TABLE `pecas` DISABLE KEYS */;
INSERT INTO `pecas` VALUES (1,'vestido','para o verão','321',0,0,'2015-10-27 03:55:48',3),(2,'sainha','curta','98',1,0,'2015-10-27 04:02:55',3);
/*!40000 ALTER TABLE `pecas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguidores`
--

DROP TABLE IF EXISTS `seguidores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguidores` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_criacao_seguidor` datetime NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `lojista_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `cliente_id` (`cliente_id`),
  KEY `lojista_id` (`lojista_id`),
  CONSTRAINT `seguidores_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  CONSTRAINT `seguidores_ibfk_2` FOREIGN KEY (`lojista_id`) REFERENCES `lojistas` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguidores`
--

LOCK TABLES `seguidores` WRITE;
/*!40000 ALTER TABLE `seguidores` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguidores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_categorias`
--

DROP TABLE IF EXISTS `user_categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_categorias` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `data_criacao_busca_categoria` datetime NOT NULL,
  `user_id` int(11) NOT NULL,
  `categoria_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `categoria_id` (`categoria_id`),
  CONSTRAINT `user_categorias_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `user_categorias_ibfk_2` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user_categorias`
--

LOCK TABLES `user_categorias` WRITE;
/*!40000 ALTER TABLE `user_categorias` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `new_user` tinyint(1) NOT NULL DEFAULT '1',
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'master','master@master.com','$2y$10$.DsS8nzHa4BCkamKQwaWzOJyrF63TJgp8YhH60kihbnlIQkammBhm',1,0,'oevgy4GGVIIWkv4jNB1lAbjgeHmcpElFfFUfMHqDN8HrxH6Zrl760vuwVLew','2015-10-27 05:22:56','2015-10-27 08:03:48'),(2,'bruna','bruna@bruna.com','$2y$10$OTpczT8Mn4JxDkNgSmIjb.IYMDAOQkfvJGanAc.w7qeEqr.JDkzG6',3,0,'iKo31xrx562gymMTE7gYMYqDeRl6FhUCVXsrsahn2FhgfUJOwXz3sPuduXs8','2015-10-27 05:27:59','2015-10-27 07:29:46'),(3,'zara','zara@zara.com','$2y$10$vuaIPu/l/H9xBV1R8fACKem9ekGMN1b7vqJlzCGc39My4Gf1Zm0ye',2,0,'LWgWb1I0r4P1erH9EGanzzaNF5XdiWHqvJcMsufia42mASBfwVHXKrt3OaLr','2015-10-27 05:28:31','2015-10-27 08:02:58'),(5,'tng','tng@tng.com','$2y$10$GR2Vvj3nO14NVN8GLP.COOEGy7EUVHG4PUiFUYw8BA5pzcYF0XoWO',2,0,'CNHNZJud7hsxXfQCO4m7akZrrblYjeM5npXDUCOWSoyNgCSo6Plv8QeVwQJ9','2015-10-27 05:44:12','2015-10-27 08:01:28'),(6,'pernambucanas','perna@perna.com','$2y$10$SE.hGkXuKIJJ0Zyvp3Ef0OYeKxMnTolvVhwuFqm7lY2/AM4lT8YWu',2,1,NULL,'2015-10-27 06:01:53','2015-10-27 06:01:53');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-10-27  4:04:50
