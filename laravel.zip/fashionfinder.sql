-- MySQL dump 10.13  Distrib 5.6.24, for osx10.8 (x86_64)
--
-- Host: 127.0.0.1    Database: fashionfinder
-- ------------------------------------------------------
-- Server version   5.6.26

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES ('2014_10_12_000000_create_users_table',1),('2014_10_12_100000_create_password_resets_table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  KEY `password_resets_email_index` (`email`),
  KEY `password_resets_token_index` (`token`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `new_user` TINYINT(1) NOT NULL DEFAULT 1,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-09-25 15:09:23

CREATE TABLE categorias (
    id INT NOT NULL AUTO_INCREMENT,
    nome_categoria VARCHAR(255) NOT NULL,
    nova_categoria TINYINT(1) NOT NULL DEFAULT 1,
    data_criacao_categoria DATETIME NOT NULL,
    PRIMARY KEY(id)
)   ENGINE=INNODB;

CREATE TABLE clientes (
    id INT NOT NULL AUTO_INCREMENT,
    doc_cliente VARCHAR(255) NULL,
    endereco_cliente VARCHAR(255) NULL,
    cep_cliente VARCHAR(255) NULL,
    telefone_cliente VARCHAR(255) NULL,
    instagram_cliente VARCHAR(255) NULL,
    facebook_cliente VARCHAR(255) NULL,
    data_criacao_cliente DATETIME NOT NULL,
    user_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (user_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id)

)   ENGINE=INNODB;

CREATE TABLE lojistas (
    id INT NOT NULL AUTO_INCREMENT,
    cnpj_lojista VARCHAR(255) NULL,
    endereco_lojista VARCHAR(255) NULL,
    cep_lojista VARCHAR(255) NULL,
    telefone_lojista VARCHAR(255) NULL,
    instagram_lojista VARCHAR(255) NULL,
    facebook_lojista VARCHAR(255) NULL,
    site_lojista VARCHAR(255) NULL,
    data_criacao_lojista DATETIME NOT NULL,
    user_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (user_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id)
      
)   ENGINE=INNODB;

CREATE TABLE buscas (
    id INT NOT NULL AUTO_INCREMENT,
    palavras_busca VARCHAR(255) NOT NULL,
    data_criacao_busca DATETIME NOT NULL,
    user_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (user_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id)
      
)   ENGINE=INNODB;

CREATE TABLE seguidores (
    id INT NOT NULL AUTO_INCREMENT,
    data_criacao_seguidor DATETIME NOT NULL,
    cliente_id INT NOT NULL,
    lojista_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (cliente_id),
    INDEX (lojista_id),

    FOREIGN KEY (cliente_id)
      REFERENCES clientes(id),

    FOREIGN KEY (lojista_id)
      REFERENCES lojistas(id)
      
)   ENGINE=INNODB;

CREATE TABLE pecas (
    id INT NOT NULL AUTO_INCREMENT,
    nome_peca VARCHAR(255) NOT NULL,
    descricao_peca TEXT NOT NULL,
    codigo_peca VARCHAR(255) NOT NULL,
    nova_peca TINYINT(1) NOT NULL DEFAULT 1,
    curtidas_peca INT NOT NULL DEFAULT 0,
    data_criacao_peca DATETIME NOT NULL,
    user_id INT NOT NULL,
    
    PRIMARY KEY(id),
    INDEX (user_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id)

)   ENGINE=INNODB;

CREATE TABLE peca_categorias (
    id INT NOT NULL AUTO_INCREMENT,
    peca_id INT NOT NULL,
    categoria_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (peca_id),
    INDEX (categoria_id),

    FOREIGN KEY (peca_id)
      REFERENCES pecas(id),

    FOREIGN KEY (categoria_id)
      REFERENCES categorias(id)
      
)   ENGINE=INNODB;

CREATE TABLE user_categorias (
    id INT NOT NULL AUTO_INCREMENT,
    data_criacao_busca_categoria DATETIME NOT NULL,
    user_id INT NOT NULL,
    categoria_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (user_id),
    INDEX (categoria_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id),

    FOREIGN KEY (categoria_id)
      REFERENCES categorias(id)
      
)   ENGINE=INNODB;

CREATE TABLE curtidas (
    id INT NOT NULL AUTO_INCREMENT,
    data_criacao_curtida DATETIME NOT NULL,
    user_id INT NOT NULL,
    peca_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (user_id),
    INDEX (peca_id),

    FOREIGN KEY (user_id)
      REFERENCES users(id),

    FOREIGN KEY (peca_id)
      REFERENCES pecas(id)
      
)   ENGINE=INNODB;

CREATE TABLE fotos (
    id INT NOT NULL AUTO_INCREMENT,
    nome_foto VARCHAR(255) NOT NULL,
    extensao_foto VARCHAR(255) NOT NULL,
    caminho_foto VARCHAR(255) NOT NULL,
    peca_id INT NOT NULL,

    PRIMARY KEY(id),
    INDEX (peca_id),

    FOREIGN KEY (peca_id)
      REFERENCES pecas(id)

)   ENGINE=INNODB;
