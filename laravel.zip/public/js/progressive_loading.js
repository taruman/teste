$(window).scroll(function(){
	if ($(window).scrollTop() == $(document).height() - $(window).height()){
		AddMoreContent();
	}
});

function AddMoreContent(){
	$.post('content.php', function(data){
		$(data).insertBefore($('#content'));
	});
}