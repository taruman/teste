$(window).scroll(function(){
	if ($(document).scrollTop() > 450){
		$('.navbar').css('margin-top','-50px');
	} else {
		$('.navbar').css('margin-top','0px');
	}
});